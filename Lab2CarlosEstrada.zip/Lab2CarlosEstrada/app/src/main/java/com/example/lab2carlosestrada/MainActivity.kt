package com.example.lab2carlosestrada

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.lab2carlosestrada.ui.theme.Lab2CarlosEstradaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Lab2CarlosEstradaTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Android")
                }
            }
        }
    }
}

fun main() {
//Parte1............................................................................................
    // Crear una lista
    val listNum = listOf(7.0, 2.0, 3.0, 4.0, 5.0)
    // Calcular Promedio
    val promedio = calcularPromedio(listNum)
    println("Parte1:")
    println("El promedio es: $promedio\n")

//Parte2............................................................................................
    println("Parte2:")
    // Crear una lista de enteros
    val L = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    // Usar la función 'filter' para extraer números impares y almacenarlos en una nueva lista
    val LImpar = L.filter { it % 2 != 0 }

    // Imprimir la lista original y la lista de impares
    println("Lista original: $L")
    println("Lista de impares: $LImpar\n")

//Parte3............................................................................................
    println("Parte3:")
    println(isPalindrome("radar"))     // true
    println(isPalindrome("level"))     // true
    println(isPalindrome("hello"))     // false
    println(isPalindrome("Able was I ere I saw Elba")) // true

//Parte4............................................................................................
    println("\nParte4:")
    // Crear una lista de cadenas que representen nombres
    val nombres = listOf("Alicia", "Bob", "Carlos", "Diana")

    // Agregar el saludo "¡Hola, " antes de cada nombre utilizando la función 'map'
    val saludos = nombres.map { nombre -> "¡Hola, $nombre!" }

    // Imprimir la lista de saludos
    saludos.forEach { println(it) }

//Parte5............................................................................................
    println("\nParte5:")
    // Definir la operación de suma como una lambda
    val sumaLambda: (Int, Int) -> Int = { x, y -> x + y }

    // Definir la operación de resta como una lambda
    val restaLambda: (Int, Int) -> Int = { x, y -> x - y }

    // Realizar la operación de suma con los enteros 5 y 3
    val Rsuma = performOperation(5, 3, sumaLambda)
    println("Resultado de la suma: $Rsuma") // Resultado de la suma: 8

    // Realizar la operación de resta con los enteros 10 y 7
    val Rresta = performOperation(10, 7, restaLambda)
    println("Resultado de la resta: $Rresta") // Resultado de la resta: 3

//Parte6............................................................................................
    println("\nParte6:")
    val personList = listOf(
        Person("Alicia", 20, "F"),
        Person("Bob", 22, "M"),
        Person("Eve", 19, "F")
    )

    val studentList = mapToStudents(personList)

    for (student in studentList) {
        println("El Estudiante ${student.name} tiene ${student.age} años")
    }
}

//--------------------------------------------FUNCIONES--------------------------------------------
//Parte1............................................................................................
fun calcularPromedio(listNum: List<Double>): Double {
    if (listNum.isEmpty()) {
        throw IllegalArgumentException("La lista está vacía")
    }

    val suma = listNum.reduce { acc, numero -> acc + numero }

    val promedio = suma / listNum.size.toDouble()

    return promedio
}

//Parte3............................................................................................
fun isPalindrome(cadena: String): Boolean {
    val str = cadena.toLowerCase().filter { it.isLetterOrDigit() }
    return str == str.reversed()
}

//Parte5............................................................................................
fun performOperation(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
    return operation(a, b)
}

//Parte6............................................................................................
data class Person(val name: String, val age: Int, val gender: String)
data class Student(val name: String, val age: Int, val gender: String, val studentId: String)

fun mapToStudents(personList: List<Person>): List<Student> {
    return personList.map { person ->
        Student(person.name, person.age, person.gender, "S${person.age}${person.name[0]}")
    }
}


@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Lab2CarlosEstradaTheme {
        Greeting("Android")
    }
}